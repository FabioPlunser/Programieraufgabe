public class InvalidTrainException extends RuntimeException{
    public InvalidTrainException(String message) {
        super(message);
    }
}
