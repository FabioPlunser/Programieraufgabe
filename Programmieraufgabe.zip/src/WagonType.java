public enum WagonType {
    PASSENGER, SLEEP, EATING, GOODS
}
