public enum DriveType {
    DIESEL, ELECTRIC, STEAM
}
